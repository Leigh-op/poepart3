 package part3;

import java.util.ArrayList;
import java.util.Scanner;

public class Part3 {
    // Array / Lists for part 3 requirements
    private ArrayList<String> sentMessages = new ArrayList<>();
    private ArrayList<String> disregardedMessages = new ArrayList<>();
    private ArrayList<String> storedMessages = new ArrayList<>();
    private ArrayList<String> messageHashes = new ArrayList<>();
    private ArrayList<String> messageIDs = new ArrayList<>();
    private ArrayList<String> recipients = new ArrayList<>();

    public Part3() {
        // Constructor
    }

    public void loadTestData() {
        addMessage("+27834557896", "Did you get the cake?", "Sent");
        addMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        addMessage("+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        addMessage("0838884567", "It is dinner time!", "Sent");
        addMessage("+27838884567", "Ok, I am leaving without you.", "Stored");
    }

    public void addMessage(String recipient, String message, String flag) {
        recipients.add(recipient);
        String messageID = "MSG" + (messageIDs.size() + 1);
        messageIDs.add(messageID);
        
        String hash = generateHash(message);
        messageHashes.add(hash);

        if (flag.equalsIgnoreCase("Sent")) {
            sentMessages.add(message);
        } else if (flag.equalsIgnoreCase("Disregard") || flag.equalsIgnoreCase("Disregarded")) {
            disregardedMessages.add(message);
        } else if (flag.equalsIgnoreCase("Stored")) {
            storedMessages.add(message);
        }
    }

    private String generateHash(String message) {
        if (message.length() > 5) {
            return message.substring(0, 5).toUpperCase() + message.length();
        }
        return message.toUpperCase() + message.length();
    }

    // a. Display sender and recipient of all stored messages[cite: 2]
    public String displayStoredSendersAndRecipients() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedMessages.size(); i++) {
            sb.append("Recipient: ").append(recipients.get(i))
              .append(", Message: ").append(storedMessages.get(i)).append("\n");
        }
        return sb.toString();
    }

    // b. Display the longest stored message[cite: 2]
    public String displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        String longest = storedMessages.get(0);
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    // c. Search for a message ID and display corresponding recipient and message[cite: 2]
    public String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equalsIgnoreCase(id)) {
                return "Recipient: " + recipients.get(i) + ", Message: " + sentMessages.get(Math.min(i, sentMessages.size() - 1));
            }
        }
        return "Message ID not found.";
    }

    // d. Search for all messages stored for a particular recipient[cite: 2]
    public String searchMessagesByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipientNumber)) {
                sb.append(messageIDs.get(i)).append(": ").append(recipients.get(i)).append("\n");
            }
        }
        return sb.length() > 0 ? sb.toString().trim() : "No messages found for this recipient.";
    }

    // e. Delete a message using the message hash[cite: 2]
    public boolean deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equalsIgnoreCase(hash)) {
                messageHashes.remove(i);
                messageIDs.remove(i);
                recipients.remove(i);
                return true;
            }
        }
        return false;
    }

    // f. Display a report that lists the full details of all the stored messages[cite: 2]
    public String displayReport() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageHashes.size(); i++) {
            sb.append("Hash: ").append(messageHashes.get(i))
              .append(" | Recipient: ").append(recipients.get(i))
              .append(" | ID: ").append(messageIDs.get(i))
              .append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Part3 manager = new Part3();
        manager.loadTestData();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Send a Message");
            System.out.println("2. Show Inbox");
            System.out.println("3. View Reports");
            System.out.println("4. Stored Messages");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            while (!scanner.hasNextInt()) {
                scanner.next();
                System.out.print("Please enter a valid number: ");
            }
            choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 4) {
                char subChoice;
                do {
                    System.out.println("\n--- STORED MESSAGES MENU ---");
                    System.out.println("a. Display sender and recipient of all stored messages");
                    System.out.println("b. Display the longest stored message");
                    System.out.println("c. Search for a message ID and display recipient and message");
                    System.out.println("d. Search for all the messages stored for a particular recipient");
                    System.out.println("e. Delete a message using the message hash");
                    System.out.println("f. Display a report that lists the full details");
                    System.out.println("g. Return to Main Menu");
                    System.out.print("Enter option (a-g): ");
                    subChoice = scanner.nextLine().toLowerCase().charAt(0);

                    switch (subChoice) {
                        case 'a':
                            System.out.println(manager.displayStoredSendersAndRecipients());
                            break;
                        case 'b':
                            System.out.println("Longest Message: " + manager.displayLongestStoredMessage());
                            break;
                        case 'c':
                            System.out.print("Enter Message ID: ");
                            String id = scanner.nextLine();
                            System.out.println(manager.searchByMessageID(id));
                            break;
                        case 'd':
                            System.out.print("Enter Recipient Number: ");
                            String rec = scanner.nextLine();
                            System.out.println(manager.searchMessagesByRecipient(rec));
                            break;
                        case 'e':
                            System.out.print("Enter Message Hash: ");
                            String hash = scanner.nextLine();
                            if (manager.deleteByHash(hash)) {
                                System.out.println("Message successfully deleted.");
                            } else {
                                System.out.println("Hash not found.");
                            }
                            break;
                        case 'f':
                            System.out.println(manager.displayReport());
                            break;
                        case 'g':
                            break;
                        default:
                            System.out.println("Invalid option.");
                    }
                } while (subChoice != 'g');
            }
        } while (choice != 5);
        scanner.close();
    }
}