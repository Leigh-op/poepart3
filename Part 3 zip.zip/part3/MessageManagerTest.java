 package part3;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageManagerTest {
    
    private Part3 manager;

    @Before
    public void setUp() {
        manager = new Part3();
        manager.loadTestData();
    }

    @After
    public void tearDown() {
        manager = null;
    }

    @Test
    public void testDisplayLongestStoredMessage() {
        String result = manager.displayLongestStoredMessage();
        assertEquals("Where are you? You are late! I have asked you to be on time.", result);
    }

    @Test
    public void testSearchByMessageID() {
        String result = manager.searchByMessageID("MSG4");
        assertNotNull("The result should not be null", result);
    }

    @Test
    public void testSearchMessagesByRecipient() {
        String result = manager.searchMessagesByRecipient("+27838884567");
        assertNotNull("The search result should not be null", result);
    }

    @Test
    public void testDeleteByHash() {
        boolean success = manager.deleteByHash("WHERE58");
        assertTrue("Message should be successfully deleted by hash", success);
    }

    @Test
    public void testDisplayReport() {
        String report = manager.displayReport();
        assertNotNull("Report should be generated successfully", report);
    }
}








